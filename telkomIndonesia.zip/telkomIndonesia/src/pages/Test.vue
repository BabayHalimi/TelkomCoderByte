<template>
	<q-page>
		<h1>Babay Halimi Test Page</h1>
	</q-page>
</template>