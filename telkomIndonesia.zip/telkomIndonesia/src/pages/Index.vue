<template>
  <div class="q-pa-md wrap-body">
    <!-- <img
      alt="Quasar logo"
      src="~assets/quasar-logo-vertical.svg"
      style="width: 200px; height: 200px"
    > -->
    <div class="row">
      <div class="col-6 q-pr-md">
        <div class="wrapbox q-pa-md">
          Delivery <q-icon name="fa-regular fa-circle-check" />
          <p>Mobile Entry - Free</p>
          <p>
            Tickets Available by Sun Apr 3, 2022 <br>
            These mobile tickets will be transferred directly to you from a trusted seller. We`ll email you instructions on how to accept them on the originial ticket provider`s mobile app.
          </p>
        </div>
        <div class="wrapbox q-mt-md q-pa-md">
          <p>Payment <q-icon name="fa-regular fa-circle-check" /></p>
          <p>Use Credit / Debit Card</p>
           <q-card class="my-card">
            <q-card-section>
              <div class="row">
                <div class="col-1">
                  <q-icon name="fa-regular fa-circle-dot" />
                </div>
                <div class="col-11">
                  Visa - 9999
                  User Name | exp. 00/11 <br>
                  Edit | Delete
                </div>
              </div>
            </q-card-section>
          </q-card>


        </div>
      </div>
      <div class="col-6 wrapbox q-pa-md">
        Total
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'PageIndex'
}
</script>

<style scoped lang="scss">
  .wrap-body {
    margin: 5% 20%;
    
  }
  .wrapbox {
    border:1px solid #ccc
  }
</style>
